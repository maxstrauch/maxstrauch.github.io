#!/bin/sh

ant jar

mkdir tmpdir
cd tmpdir/
7z x -y ../dist/cryptbag.jar

rm -r META-INF/
mkdir META-INF

jar -cf cryptbag.jar .


echo "Manifest-Version: 1.0\nMain-Class: Cryptbag\n" > META-INF/MANIFEST.MF

7z a cryptbag.jar META-INF/

pack200 --repack --effort=9 --segment-limit=-1 --modification-time=latest --strip-debug cryptbag.jar

cp cryptbag.jar ../

cd ..

rm -r tmpdir/