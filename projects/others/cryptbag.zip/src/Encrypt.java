import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Encrypt {
    
    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.out.println("Usage: java Encrypt <File src> <key>");
            return;
        }
        
        File src = new File(args[0]);
        
        System.out.println(src);
        System.out.println(" -> ");
        
        String path = src.getAbsolutePath();
        File dst = new File(path.substring(0, path.lastIndexOf(File.separatorChar)) + File.separatorChar + "dat.raw");
        String key = args[1];

        System.out.println(dst);
        System.out.println("Key: " + key.length() + " chars");
        
        AESOutputStream aos = new AESOutputStream(new FileOutputStream(dst), key);
        FileInputStream fis = new FileInputStream(src);
        
        byte[] buffer = new byte[1024];
        int length;
        while ((length = fis.read(buffer)) > 0) {
            aos.write(buffer, 0, length);
        }
        
        fis.close();
        aos.close();
        
    }
    
}
