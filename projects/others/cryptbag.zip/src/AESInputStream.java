import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESInputStream extends InputStream {

    private final InputStream stream;
    private final String key;
    private int[] data;
    private int pointer;
    
    public AESInputStream(InputStream stream, String key) {
        this.stream = stream;
        this.key = key;
        this.data = null;
        this.pointer = -1;
    }
    
    private void readData() throws IOException {
        pointer = 0;
        
        // Read all
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int b;
        while ((b = stream.read()) > -1) {
            baos.write(b);
        }
        byte[] encryptedData = baos.toByteArray();
        
        // Make keys
        byte[] key = AESOutputStream.getDigest(this.key, 0, 16);
        byte[] iv = AESOutputStream.getDigest(this.key, 16, 16);
        
        // Decrypt
        byte[] rawData;
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding", "SunJCE");
            SecretKeySpec cipherKey = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.DECRYPT_MODE, cipherKey, new IvParameterSpec(iv));
            rawData = cipher.doFinal(encryptedData);
        } catch (Exception ex) {
            throw new IOException(ex);
        }
        
        // Extract data from raw data
        int magic = readIntFromByteArray(rawData, 0);
        if (magic != AESOutputStream.MAGIC) {
            throw new IOException("Failed to decrypt input! Wrong key.");
        }
        
        int length = readIntFromByteArray(rawData, 4);
        data = new int[length];
        for (int i = 0; i < length; i++) {
            data[i] = (int) rawData[i + 8] & 0xff;
        }
    }
    
    @Override
    public int read() throws IOException {
        if (data == null) {
            readData();
        }
        
        if (pointer >= data.length) {
            return -1;
        }
        
        int b = data[pointer];
        pointer++;
        return b;
    }
    
    public static final int readIntFromByteArray(byte[] b, int offset) {
        return b[offset+3] & 0xFF |
            (b[offset+2] & 0xFF) << 8 |
            (b[offset+1] & 0xFF) << 16 |
            (b[offset+0] & 0xFF) << 24;
    }
    
}
