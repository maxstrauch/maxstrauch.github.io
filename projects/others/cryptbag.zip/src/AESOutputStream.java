import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESOutputStream extends OutputStream {
    
    public static final int MAGIC = 0x2a15;
    
    private final OutputStream stream;
    private final String key;
    private final ByteArrayOutputStream baos;
    private int length;
    
    public AESOutputStream(OutputStream stream, String key) {
        this.stream = stream;
        this.key = key;
        this.baos = new ByteArrayOutputStream();
        this.length = 0;
    }

    @Override
    public void write(int b) throws IOException {
        baos.write(b);
        length++;
    }

    @Override
    public void close() throws IOException {
        baos.close();
        
        // Make the data a multiple of 16 bytes
        byte[] magic = intToByteArray(MAGIC);
        byte[] prefix = intToByteArray(length);
        length += 4;
        length += 4;
        byte[] body = baos.toByteArray();
        byte[] rest = new byte[16 - (length % 16)];
        for (int i = 0; i < rest.length; i++) {
            rest[i] = (byte) (((int) Math.round(Math.random() * 128d)) & 0xff);
        }
        
        // Combine to total array
        byte[] bytes = new byte[magic.length + prefix.length + body.length + rest.length]; 
        System.arraycopy(magic, 0, bytes, 0, magic.length);
        System.arraycopy(prefix, 0, bytes, magic.length, prefix.length);
        System.arraycopy(body, 0, bytes, magic.length + prefix.length, body.length);
        System.arraycopy(rest, 0, bytes, magic.length + prefix.length + body.length, rest.length);
        
        byte[] result;
        try {
            // Make keys
            byte[] key = getDigest(this.key, 0, 16);
            byte[] iv = getDigest(this.key, 16, 16);
            
            // Crypt
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding", "SunJCE");
            SecretKeySpec cipherKey = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, cipherKey, new IvParameterSpec(iv));
            result = cipher.doFinal(bytes);
        } catch (Exception ex) {
            throw new IOException(ex);
        }
        
        stream.write(result);
        stream.close();
    }
    
    public static final byte[] getDigest(String key, int off, int length) 
            throws IOException {
        try {
            MessageDigest keyDigest = MessageDigest.getInstance("SHA-256");
            byte[] keyBytesDigest = keyDigest.digest(key.getBytes("UTF-8"));
            byte[] result = new byte[length];
            System.arraycopy(keyBytesDigest, off, result, 0, length);
            return result;
        } catch (Exception ex) {
            throw new IOException(ex);
        }
    }
    
    public static final byte[] intToByteArray(int a) {
        return new byte[] {
            (byte) ((a >> 24) & 0xFF),
            (byte) ((a >> 16) & 0xFF),   
            (byte) ((a >> 8) & 0xFF),   
            (byte) (a & 0xFF)
        };
    }
    
}
