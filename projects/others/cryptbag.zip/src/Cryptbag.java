import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

public class Cryptbag extends JFrame implements ActionListener {

    private final JPasswordField pwdField;
    private final JButton open;
    private final ImagePane pane;
    private JPanel cardPanel;
    
    public Cryptbag() {
        super("Cryptbag");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        pwdField = new JPasswordField(14);
        open = new JButton("Decrypt & show");
        pane = new ImagePane();
        initGui();
    }
    
    private void initGui() {
        cardPanel = new JPanel();
        cardPanel.setLayout(new CardLayout());
        add(cardPanel, BorderLayout.CENTER);
        
        JPanel pwdPrompt = new JPanel(new FlowLayout());
        pwdPrompt.setPreferredSize(new Dimension(600, 400));
        pwdPrompt.add(new JLabel("Key:"));
        pwdPrompt.add(pwdField);
        pwdField.addActionListener(this);
        open.addActionListener(this);
        pwdPrompt.add(open);
        cardPanel.add(pwdPrompt, "pwd");
        
        cardPanel.add(new JScrollPane(pane), "img");
        
        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "pwd");
    }

    @Override
    public void setEnabled(boolean b) {
        super.setEnabled(b);
        pwdField.setEnabled(b);
        open.setEnabled(b);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        new Decryptor().execute();
    }
    
    private void fail(Exception ex) {
        JOptionPane.showMessageDialog(
                this, 
                "The given key is wrong!" 
                        + (ex != null ? "\n" + ex.toString() : ""), 
                "Error", 
                JOptionPane.ERROR_MESSAGE
        );
        System.exit(0);
    }
    
    private void success(BufferedImage buf) {
        pane.setImage(buf);
        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "img");
    }

    public class ImagePane extends JComponent{
	private Image img;
        
        public ImagePane() {
            img = null;
            setPreferredSize(new Dimension(0, 0));
        }
        
	public void setImage(Image img) {
            this.img = img;

            int w = img.getWidth(this);
            int h = img.getHeight(this);

            setPreferredSize(new Dimension(w, h));
            
            invalidate();
            revalidate();
            repaint();
	}
	
        @Override
	protected void paintComponent(Graphics g) {
            if (img == null) {
                return;
            }
            g.drawImage(img, 0, 0, this);
	}
    }
    
    class Decryptor extends SwingWorker<BufferedImage, Void> {

        Exception ex;
        
        @Override
        protected BufferedImage doInBackground() throws Exception {
            setEnabled(false);
            try {
                return internalInBackground();
            } catch (Exception ex) {
                this.ex = ex;
                return null;
            }
        }
        
        private BufferedImage internalInBackground() throws Exception {
            String secret = new String(pwdField.getPassword());
            AESInputStream ais = new AESInputStream(
                    getClass().getResourceAsStream("dat.raw"), 
                    secret
            );

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int b;
            while ((b = ais.read()) > -1) {
                baos.write(b);
            }
            byte[] decrypted = baos.toByteArray();
            return (BufferedImage) ImageIO.read(new ByteArrayInputStream(decrypted));
        }

        @Override
        protected void done() {
            BufferedImage res = null;
            try {
                res = get();
            } catch (Exception ex) {
                /* Don't watch */
            }
            
            if (res == null) {
                fail(ex);
            } else {
                success(res);
            }
            setEnabled(true);
        }
    }
    
    public static void main(String[] args) throws Exception {
        if (args.length > 0 && "encrypt".equals(args[0])) {
            if (args.length != 3) {
                Encrypt.main(new String[] {});
            } else {
                Encrypt.main(new String[] {args[1], args[2]});
            }
            return;
        }
        
        System.setProperty("apple.laf.useScreenMenuBar", "true");
        System.setProperty("com.apple.mrj.application.apple.menu.about.name", "Cryptbag");
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
       
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            /* Don't watch */
        }
        
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Cryptbag cb = new Cryptbag();
                cb.pack();
                cb.setVisible(true);
            }
        });
    }
    
}
