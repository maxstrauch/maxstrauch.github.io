#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "sha1.h"
#include "sha256.h"

// Size of the file buffer
#define BUFSIZE 1048576

void
print_usage() {
    printf("Usage: shasum [-a (1|256)] FILE1 [FILE2] [...]\n");
    printf("Calculates SHA Checksums of files.\n");
    printf("Algorithms adapted from: https://github.com/B-Con/crypto-algorithms\n\n");

    printf("Arguments:\n");
    printf("  -a\t Selects the SHA algorithm: 1, 256 (default)\n");

}

int
main(int argc,char **argv) {
	int algo = 256, verboseFlag = 0, c, hashSize, i;
	unsigned char buf[BUFSIZE];
	size_t nbr;
	FILE *fp;
	SHA256_CTX ctx256;
	SHA1_CTX ctx1;

	// Parse arguments ...
	opterr = 0; // Don't print getopt errors
	while ((c = getopt(argc, argv, "a:hv")) != -1) {
        switch (c) {
        	case 'a': // Select algorithm
        		algo = atoi(optarg);
        		switch (algo) {
        			case 1:
        				break;
        			case 256:
        				break;

        			// Print error and exit
        			default:
        				fprintf(stderr, "Error: unknown algorithm %i\n", algo);
        				return 1;
        		}
        		break;
			case 'v': // Verbose flag
    			verboseFlag = 1;
    			break;

	        case 'h':
          		print_usage();
          		return 0;
        	case '?':
        	default:
          		fprintf(stderr, "Unknown option `-%c' or missing argument.\n\n", optopt);
          		return 1;
        }
    }

    // Check if there are any files to work on
    if (optind >= argc) {
    	fprintf(stderr, "Error: No files given to work on.\n\n");
    	print_usage();
        return 1;
    }

    // Otherwise calculate SHA sums for every input file
    if (verboseFlag) {
		printf("Using SHA%i algorithm\n", algo);
	}

    do {
    	char *file = argv[optind];
    	if (verboseFlag) {
    		printf("Working on input file: %s\n", file);
    	}

    	// Open the file in binary mode otherwise the windows port
        // will not work correctly
    	if ((fp = fopen(file, "rb")) == NULL) {
    		fprintf(stderr, "Error: can't open file %s.\n", file);
    		continue;
    	}

    	// Perform the right algorithm
    	switch (algo) {
    		// SHA-1
    		case 1:
    			hashSize = SHA1_BLOCK_SIZE;
				sha1_init(&ctx1);

				// Calculate the hash
				for (;;) {
					if ((nbr = fread(buf, sizeof(char), BUFSIZE, fp)) < 1) {
						break; // EOF
					}
					sha1_update(&ctx1, buf, nbr);
				}

				// Save the hash
				memset(buf, 0, BUFSIZE);
				sha1_final(&ctx1, buf);
    			break;

    		// SHA-256
    		case 256:
    			hashSize = SHA256_BLOCK_SIZE;
				sha256_init(&ctx256);

				// Calculate the hash
				for (;;) {
					if ((nbr = fread(buf, sizeof(char), BUFSIZE, fp)) < 1) {
						break; // EOF
					}
					sha256_update(&ctx256, buf, nbr);
				}

				// Save the hash
				memset(buf, 0, BUFSIZE);
				sha256_final(&ctx256, buf);
    			break;
    	}

    	// Print the hash to stdout
		for (i = 0; i < hashSize; i++) {
			printf("%02x", buf[i] & 0xff);
		}
		printf("  %s\n", file);
    } while (++optind < argc);

    return 0; /* Everything fine */
}
